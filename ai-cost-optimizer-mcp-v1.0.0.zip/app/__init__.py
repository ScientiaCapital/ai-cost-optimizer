"""AI Cost Optimizer - Simple multi-LLM routing system"""
__version__ = "1.0.0"
